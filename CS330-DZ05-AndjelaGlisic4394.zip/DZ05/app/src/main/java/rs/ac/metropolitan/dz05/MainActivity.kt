package rs.ac.metropolitan.dz05

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

public class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button1)
        button.setOnClickListener {
            showOptionsDialog()
        }
    }

    private fun showOptionsDialog() {
        val options = arrayOf("FIT", "FAM", "FDU")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Izaberite fakultet")
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> openWebsite("https://www.metropolitan.ac.rs/osnovne-studije/fakultet-informacionih-tehnologija/")
                1 -> openWebsite("https://www.metropolitan.ac.rs/osnovne-studije/fakultet-za-menadzment/")
                2 -> openWebsite("https://www.metropolitan.ac.rs/fakultet-digitalnih-umetnosti-2/")
            }
        }
        builder.show()
    }

    private fun openWebsite(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }
}
