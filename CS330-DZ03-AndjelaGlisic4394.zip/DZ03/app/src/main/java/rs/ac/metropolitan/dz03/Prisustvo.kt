package rs.ac.metropolitan.dz03

class Prisustvo {
    private var listaStudenata: MutableMap<Int, String> = mutableMapOf(
        4394 to "Andjela Glisic",
        4511 to "Tamara Mladenovic"
    )
}