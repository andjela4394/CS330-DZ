package rs.ac.metropolitan.myapplication

class BMICalculator {
    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            print("Unesite vašu visinu (u cm): ")
            val height = readLine()?.toDouble() ?: 0.0
            print("Unesite vašu težinu (u kg): ")
            val weight = readLine()?.toDouble() ?: 0.0

            val bmi = weight / ((height/100) * (height/100))
            println("Vaš BMI je: %.2f".format(bmi))
        }
    }
}