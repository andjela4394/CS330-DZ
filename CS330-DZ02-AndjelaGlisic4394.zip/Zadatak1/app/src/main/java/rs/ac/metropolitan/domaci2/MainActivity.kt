package ac.rs.metropolitan.domaci2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import rs.ac.metropolitan.domaci2.ui.theme.Domaci2Theme
import java.lang.Math.pow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Domaci2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    MainView()
                }
            }
        }
    }
}

@Composable
fun MainView() {
    Scaffold (
        topBar = {
            TopAppBar {
                Text (text = "BMI Calculator", style = MaterialTheme.typography.h5)
            }
        }
    ){ contentPadding ->
        Counter(contentPadding)
    }
}

@Composable
fun Counter(contentPadding: PaddingValues) {
    val counter = remember { mutableStateOf(0.0) }

    var firstText  = remember { mutableStateOf(TextFieldValue(""))}
    var secondText = remember { mutableStateOf(TextFieldValue(""))}

    Column (
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly,
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
    ) {


        Column(){
            TextField(
                value = firstText.value,
                placeholder = { Text(text = "Visina(cm)") },
                onValueChange = {  firstText.value = it})
            TextField(
                value = secondText.value,
                placeholder = { Text(text = "Težina(kg)") },
                onValueChange = { secondText.value = it})
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.Center
        )
        {
            Button(onClick = { counter.value = secondText.value.text.toDouble() / pow(firstText.value.text.toDouble()/100, 2.0 ) })
            { Text(text = "Izračunaj", style = MaterialTheme.typography.h3) }

        }
        Text(text = "Rezultat: ${"%.2f".format(counter.value)}", style = MaterialTheme.typography.h3)
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    Domaci2Theme {
        MainView()
    }
}